// --- Archivo: polleria-montiel-pos/js/app.js (Versión Final Corregida y Unificada) ---
import { catalogoProductos } from './data/productos.js';
import { listaClientes } from './data/clientes.js';

const PosApp = {
    state: {
        clienteActual: { nombre: 'Público en General', tipoPrecio: 'publico', badgeClass: 'badge-amarillo-polleria' },
        carrito: [],
        productoEnModal: null,
        currentView: null,
    },
    data: {
        productos: new Map(),
        clientes: listaClientes,
    },
    ui: {},

    // --- 1. INICIALIZACIÓN ---
    init() {
        catalogoProductos.forEach(p => this.data.productos.set(p.id, p));
        this.cacheGlobalUI();
        this._bindGlobalEvents();
        this.router(); // Inicia el proceso de carga de la primera vista
    },

    // --- 2. ROUTING Y CARGA DE VISTAS ---
    async router() {
        const routes = {
            '/': 'dashboard',
            '/venta': 'venta',
            '/productos': 'dashboard',
            '/clientes': 'dashboard',
            '/reportes': 'dashboard',
        };
        const path = location.hash.slice(1) || '/';
        const viewName = routes[path] || 'dashboard';
        await this.loadView(viewName);
    },

    async loadView(viewName) {
        // Optimización: No recargar la misma vista si ya está activa
        if (this.state.currentView === viewName) return; 
        this.state.currentView = viewName;

        try {
            const response = await fetch(`./views/${viewName}.html`);
            if (!response.ok) throw new Error(`Vista no encontrada: ${viewName}`);
            
            // Carga el HTML de la vista en el contenedor principal
            this.ui.appContainer.innerHTML = await response.text();
            this.ui.posFooter.style.display = (viewName === 'venta') ? 'flex' : 'none';
            
            // Una vez cargado el HTML, se ejecuta la lógica post-carga
            this.afterViewLoad(viewName);
        } catch (error) {
            console.error(error);
            this.ui.appContainer.innerHTML = `<p class="text-center" style="padding: var(--espacio-xl);">Error 404: La página no existe.</p>`;
        }
    },

    // --- 3. LÓGICA POST-CARGA DE VISTA ---
    afterViewLoad(viewName) {
        this.updateActiveNav();
        // Si la vista recién cargada es 'venta', preparamos todo lo necesario para ella.
        if (viewName === 'venta') {
            this.cacheVentaUI();       // Los elementos HTML ahora existen, los cacheados.
            this._bindVentaEvents();   // Asignamos eventos a esos elementos.
            this._renderVentaView();   // Renderizamos el contenido inicial (productos, carrito, etc.).
        }
    },

    // --- CACHEO DE ELEMENTOS UI ---
    cacheGlobalUI() {
        this.ui = {
            appContainer: document.getElementById('app-container'),
            posFooter: document.getElementById('pos-footer'),
            modalContainer: document.getElementById('product-modal-container'),
            modalTitle: document.getElementById('modal-product-name'),
            modalBody: document.getElementById('modal-body-content'),
            modalCloseBtn: document.getElementById('modal-close-btn'),
            modalCancelBtn: document.getElementById('modal-cancel-btn'),
            modalAddToCartBtn: document.getElementById('modal-add-to-cart-btn'),
        };
    },

    cacheVentaUI() {
        // Estos elementos solo existen después de que se carga 'venta.html'
        this.ui.productGrid = document.getElementById('product-grid-container');
        this.ui.cartTableBody = document.getElementById('ticket-items-body');
        this.ui.noItemsRow = document.getElementById('no-items-row');
        this.ui.totalAmount = document.getElementById('total-amount');
        this.ui.customerSearchInput = document.getElementById('customer-search');
        this.ui.searchResultsContainer = document.getElementById('search-results-container');
        this.ui.selectedCustomerDiv = document.getElementById('selected-customer');
        this.ui.customerNameP = document.getElementById('customer-name');
        this.ui.clientTypeBadge = document.getElementById('client-type-badge');
        this.ui.clearCustomerBtn = document.getElementById('clear-customer');
    },
    
    // --- ASIGNACIÓN DE EVENTOS ---
    _bindGlobalEvents() {
        window.addEventListener('hashchange', () => this.router());
        document.body.addEventListener('click', e => {
            const link = e.target.closest('[data-link]');
            if (link) {
                e.preventDefault();
                location.hash = new URL(link.href).hash;
            }
        });
        this.ui.modalCloseBtn.addEventListener('click', () => this._closeModal());
        this.ui.modalCancelBtn.addEventListener('click', () => this._closeModal());
        this.ui.modalAddToCartBtn.addEventListener('click', () => this._handleAddToCart());
        this.ui.modalContainer.addEventListener('click', e => {
            if (e.target === this.ui.modalContainer) this._closeModal();
        });
    },

    _bindVentaEvents() {
        // Estos eventos solo se pueden asignar si los elementos existen
        this.ui.productGrid.addEventListener('click', e => {
            const productBtn = e.target.closest('.product-btn');
            if (productBtn) this._handleProductSelection(productBtn.dataset.productId);
        });
        this.ui.customerSearchInput.addEventListener('input', e => this._handleCustomerSearch(e.target.value));
        this.ui.clearCustomerBtn.addEventListener('click', () => this._clearCustomer());
    },

    // --- 4. RENDERIZADO (DIBUJADO DE CONTENIDO) ---
    _renderVentaView() {
        // Esta función se llama solo cuando la vista 'venta' está lista
        this._renderCatalog();
        this._renderCart();
        this._renderCustomerInfo();
    },

    updateActiveNav() {
        const currentHash = location.hash || '#/';
        document.querySelectorAll('.nav-item').forEach(link => {
            link.classList.remove('active-link');
            if (link.getAttribute('href') === currentHash) {
                link.classList.add('active-link');
            }
        });
    },

    _renderCatalog() {
        if (!this.ui.productGrid) return; // Guarda de seguridad
        this.ui.productGrid.innerHTML = [...this.data.productos.values()].map(producto => `
            <button class="product-btn" data-product-id="${producto.id}">
                ${producto.nombre}
                <span>${producto.id.toUpperCase()}</span>
            </button>
        `).join('');
    },

    _renderCart() {
        if (!this.ui.cartTableBody) return;
        const totalGeneral = this.state.carrito.reduce((sum, item) => sum + item.subtotal, 0);
        this.ui.totalAmount.textContent = `$${totalGeneral.toFixed(2)}`;

        if (this.state.carrito.length === 0) {
            this.ui.cartTableBody.innerHTML = '';
            this.ui.cartTableBody.appendChild(this.ui.noItemsRow);
            return;
        }

        this.ui.cartTableBody.innerHTML = this.state.carrito.map(item => {
            const personalizacionesTexto = item.personalizaciones.map(p => p.nombre).join(', ');
            return `
                <tr>
                    <td>
                        <strong class="d-block">${item.productoNombre}</strong>
                        <small class="text-gris-secundario">${item.cantidad.toFixed(2)} ${item.tipoVenta} @ $${item.precioUnitario.toFixed(2)}/${item.tipoVenta}</small><br>
                        ${personalizacionesTexto ? `<small class="text-success">${personalizacionesTexto}</small>` : ''}
                    </td>
                    <td style="text-align: right;" class="fw-bold">$${item.subtotal.toFixed(2)}</td>
                </tr>
            `;
        }).join('');
    },

    _renderCustomerInfo() {
        if (!this.ui.customerNameP) return;
        const { nombre, tipoPrecio, badgeClass } = this.state.clienteActual;
        this.ui.customerNameP.textContent = nombre;
        this.ui.clientTypeBadge.textContent = tipoPrecio.toUpperCase();
        this.ui.clientTypeBadge.className = `badge ${badgeClass}`;

        if (nombre !== 'Público en General') {
            this.ui.selectedCustomerDiv.style.display = 'flex';
            this.ui.customerSearchInput.style.display = 'none';
        } else {
            this.ui.selectedCustomerDiv.style.display = 'none';
            this.ui.customerSearchInput.style.display = 'block';
            this.ui.customerSearchInput.value = '';
        }
    },

    // --- LÓGICA DE NEGOCIO (MODAL, CARRITO, PRECIOS) ---
    _renderModalContent(producto, productoPadreId = null) {
        this.state.productoEnModal = { ...producto, productoPadreId: productoPadreId || producto.id };

        const precioCliente = this._getPrecioCliente(this.state.productoEnModal);
        const tipoVentaTexto = producto.tipoVenta === 'peso' ? 'kg' : 'pz';
        this.ui.modalTitle.textContent = producto.nombre;

        const subproductosHTML = (producto.subproductos || []).map(sub =>
            `<button class="btn btn-secondary" data-subproduct-id="${sub.id}" style="margin-bottom: var(--espacio-s); width: 100%; background: #f0f0f0; color: #333; border-color: #ddd;">
                ${sub.nombre}
            </button>`
        ).join('');
        const subproductosGroupHTML = subproductosHTML ? `<div class="personalization-group"><h4>Variantes / Especiales</h4>${subproductosHTML}</div>` : '';

        const grupos = (producto.personalizaciones || []).reduce((acc, pers) => {
            (acc[pers.grupo] = acc[pers.grupo] || []).push(pers); return acc;
        }, {});
        const personalizacionesHTML = Object.entries(grupos).map(([nombreGrupo, pers]) => `
            <div class="personalization-group"><h4>${nombreGrupo}</h4>
                ${pers.map(p => `<label class="checkbox-label">
                    <input type="${p.tipo}" name="pers_${nombreGrupo.replace(/\s+/g, '_')}" value="${p.id}" ${p.default ? 'checked' : ''}>
                    ${p.nombre}
                </label>`).join('')}
            </div>`
        ).join('');

        this.ui.modalBody.innerHTML = `
            ${subproductosGroupHTML}
            <div class="form-group">
                <label for="modal-quantity">Cantidad (${tipoVentaTexto})</label>
                <input type="number" id="modal-quantity" value="1" step="${producto.tipoVenta === 'peso' ? 0.1 : 1}" min="0">
            </div>
            <p>Precio: <strong class="fw-bold">$${typeof precioCliente === 'number' ? precioCliente.toFixed(2) : 'Según selección'} / ${tipoVentaTexto}</strong></p>
            ${personalizacionesHTML}
        `;
        
        this.ui.modalBody.querySelectorAll('[data-subproduct-id]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const subId = e.currentTarget.dataset.subproductId;
                this._handleSubproductSelection(subId);
            });
        });

        this.ui.modalContainer.style.display = 'flex';
        document.getElementById('modal-quantity').focus();
    },

    _handleProductSelection(productId) {
        const producto = this.data.productos.get(productId);
        if (producto) this._renderModalContent(producto);
    },

    _handleSubproductSelection(subproductId) {
        const productoPadre = this.data.productos.get(this.state.productoEnModal.productoPadreId);
        if (!productoPadre) return;
        const subproducto = productoPadre.subproductos.find(s => s.id === subproductId);
        if (subproducto) {
            this._renderModalContent(subproducto, productoPadre.id);
        }
    },

    _handleAddToCart() {
        const producto = this.state.productoEnModal;
        if (!producto) return;

        const cantidad = parseFloat(document.getElementById('modal-quantity').value);
        if (isNaN(cantidad) || cantidad <= 0) {
            alert("Ingrese una cantidad válida.");
            return;
        }

        const personalizaciones = Array.from(document.querySelectorAll('#modal-body-content input:checked'))
            .map(input => (producto.personalizaciones || []).find(p => p.id === input.value))
            .filter(Boolean);

        const precioUnitario = this._getPrecioCliente(producto, cantidad, personalizaciones);
        if(typeof precioUnitario !== 'number') {
            alert("No se pudo determinar el precio. Revise la selección.");
            return;
        }

        this.state.carrito.push({
            id: Date.now(),
            productoNombre: producto.nombre,
            cantidad,
            tipoVenta: producto.tipoVenta,
            precioUnitario,
            subtotal: cantidad * precioUnitario,
            personalizaciones
        });

        this._renderCart();
        this._closeModal();
    },

    _getPrecioCliente(producto, cantidad = 1, personalizaciones = []) {
        if (producto.id === 'dsp') {
            const tipoSeleccionado = personalizaciones.find(p => p.grupo === 'Tipo');
            return tipoSeleccionado ? producto.precios[tipoSeleccionado.id] : producto.precios.surtido;
        }
        
        const tipoCliente = this.state.clienteActual.tipoPrecio;
        
        if (producto.precios.promo) {
            const promosAplicables = producto.precios.promo
                .filter(p => (!p.tipo || p.tipo === tipoCliente) && cantidad >= p.desde)
                .sort((a, b) => b.desde - a.desde); 
            
            if (promosAplicables.length > 0) {
                return promosAplicables[0].precio;
            }
        }
        return producto.precios[tipoCliente] || producto.precios.publico;
    },
    
    _handleCustomerSearch(query) {
        this.ui.searchResultsContainer.innerHTML = '';
        this.ui.searchResultsContainer.style.display = 'none';
        if (query.length < 2) return;

        const filteredClients = this.data.clientes.filter(c => c.nombre.toLowerCase().includes(query.toLowerCase()));
        if (filteredClients.length > 0) {
            this.ui.searchResultsContainer.innerHTML = filteredClients.map(client =>
                `<div class="search-result-item" data-cliente-nombre="${client.nombre}">${client.nombre} - ${client.tipoPrecio.toUpperCase()}</div>`
            ).join('');

            this.ui.searchResultsContainer.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', e => {
                    const nombre = e.target.dataset.clienteNombre;
                    const clienteSeleccionado = this.data.clientes.find(c => c.nombre === nombre);
                    if (clienteSeleccionado) this._selectCustomer(clienteSeleccionado);
                });
            });
            this.ui.searchResultsContainer.style.display = 'block';
        }
    },

    _selectCustomer(cliente) {
        this.state.clienteActual = cliente;
        if (this.ui.searchResultsContainer) {
            this.ui.searchResultsContainer.style.display = 'none';
            this.ui.customerSearchInput.value = '';
        }
        this._renderCustomerInfo();
    },

    _clearCustomer() {
        this._selectCustomer({ nombre: 'Público en General', tipoPrecio: 'publico', badgeClass: 'badge-amarillo-polleria' });
    },

    _closeModal() {
        this.ui.modalContainer.style.display = 'none';
        this.state.productoEnModal = null;
    }
};

document.addEventListener('DOMContentLoaded', () => PosApp.init());