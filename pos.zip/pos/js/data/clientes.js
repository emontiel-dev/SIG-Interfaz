export const listaClientes = [
    { nombre: 'Juan Pérez', telefono: '5512345678', tipoPrecio: 'leal', badgeClass: 'badge-azul' },
    { nombre: 'Taquería El Güero', telefono: '5522334455', tipoPrecio: 'cocina', badgeClass: 'badge-gris' },
    { nombre: 'Ana García', telefono: '5587654321', tipoPrecio: 'publico', badgeClass: 'badge-amarillo-polleria' },
    { nombre: 'Super Pollo Feliz', rfc: 'SPF010101XYZ', tipoPrecio: 'mayoreo', badgeClass: 'badge-gris' }
];